from .db_session import db
from werkzeug.security import generate_password_hash, check_password_hash
import sqlalchemy as sa
from sqlalchemy import orm


class Role(db):
    __tablename__ = 'Role'
    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    name = sa.Column(sa.String(64), unique=True)
    users = sa.orm.relationship('User', backref='role', lazy='dynamic')


class Teams(db):
    __tablename__ = 'Teams'
    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    name = sa.Column(sa.String(64), unique=True)
    points = sa.Column(sa.Integer)
    password_hash = sa.Column(sa.Integer, unique=True)
    teams = sa.orm.relationship('User', lazy='dynamic', primaryjoin="Teams.id == User.team")

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)


class User(db):
    __tablename__ = 'User'
    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    username = sa.Column(sa.String(64), unique=True, index=True)
    role_id = sa.Column(sa.Integer, sa.ForeignKey('Role.id'))
    team = sa.Column(sa.Integer, sa.ForeignKey('Teams.id'))

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)


class Tasks(db):
    __tablename__ = 'tasks'
    id = sa.Column(sa.Integer, primary_key=True)
    body = sa.Column(sa.String, unique=True)
    test = sa.Column(sa.String, unique=True)
    max_price = sa.Column(sa.Integer)
