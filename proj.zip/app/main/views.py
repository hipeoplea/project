from flask import render_template, session, redirect, url_for, current_app
from ..models import User, Role, Teams, Tasks
from . import main
from .forms import NameForm


@main.route('/', methods=['GET', 'POST'])
def index():
    form = NameForm()
    # if form.validate_on_submit():
    #     user = Role(name=form.name.data)
    #     db.session.add(user)
    #     db.session.commit()
    #     return redirect(url_for('.index'))


